# Magic Data ANNOTATOR 前端目录

Magic Data 平台前端运行时代码已拆分为“平台共享 + 助手脚本”结构。

## 目录结构

- `shared/`：同平台共享模块（页面识别、采集、network observer、共享 AI client 与 legacy 面板兼容模块）。
- `hakka-helper/`：客家话助手新版入口（兼容旧脚本 ID：`magicDataAnnotatorAiReview`）。
- `minnan-helper/`：闽南语助手入口（新脚本 ID：`magicDataMinnanAssistant`，AI 配置拆分为“模型方案 + 识别策略”）。

## 运行边界

- 平台：`https://work.magicdatatech.com/*`
- 目标页面：
  - 客家话助手：`#/asrmark`、`#/asrmarkCheck`
  - 闽南语助手：`#/asrmark`
- 两个助手都只允许用户主动点击或快捷键触发 AI。
- 不自动保存、不自动提交、不自动审核、不自动领取、不自动流转。

## 配置与入口

- options 首页统一后端地址，不在脚本详情页新增独立后端地址。
- 同平台两个助手互斥启用：同一时刻只允许一个助手处于启用状态；启用一个时会自动关闭另一个。
- popup 会在 Magic Data 页面展示当前唯一生效助手；若未启用则显示未启用状态。
- 两个助手共享后端地址入口，但配置互相独立；闽南语助手支持独立模型方案、识别策略、模型和 Prompt 参数。
- Magic Data AI 面板统一配置项：模型方案、识别策略、听音模型、比较模型、单模型、Prompt 与生成参数；thinking 当前已全局固定关闭，不再作为有效可调参数。
- 客家话助手默认已按 50 条评测结论落地：`two_stage + direct_dialect + qwen3.5-omni-flash + qwen3.5-flash`，thinking 当前已全局固定关闭。
- 客家话助手前端已切换到与闽南语助手一致的新面板体系（行内建议、三块独立折叠、全部填入、原始输出、差异对比）。
- 2026-05-27 热修：客家话助手改为通过 AI prompt 约束普通中文输出简体；命中客家话词表统一用字时继续保留，不再依赖本地后端结果二次繁转简。
- 客家话助手审核页（`#/asrmarkCheck`）已接入 AI 质检：
  - 不再显示“审核页暂未接入填入”提示；
  - 审核页默认只提供质检和风险提示，不自动保存、不自动提交；
  - 审核页文本不可编辑时不展示填入动作。
- 闽南语助手当前目标是“三项预测质检”（说话人书写、闽南语内容、普通话文本），面板左侧展示基础信息，右侧展示 AI 质检结果。
- 2026-05-26 热修：Magic Data 双助手的模型方案/识别策略/听音模型/比较模型/单模型改为显式保存，不再因“等于默认值”写空字符串，避免刷新后出现“未保存”的错觉。
- 2026-05-26 补充热修：`storage` 对 legacy `recognition_convert` 的迁移改为“显式字段优先”，避免已保存的模型方案/识别策略被回写覆盖；比较模型下拉新增独立联动更新。
- 2026-05-26 面板口径调整：Magic Data 双助手 options 不再展示“AI 质检模式”，统一以“模型方案 + 识别策略”控制 AI 行为；审核页文本可编辑时支持行内 `填入本行` 与文本项“全部填入AI推荐”（不自动保存/提交）。
- 2026-05-26 识别策略保存热修：`direct_dialect` 保存后不再被 legacy `recognition_convert` 回滚；保存时会同步覆盖 `aiReviewRecognitionMode/recognitionMode/pipelineMode`，并在平台脚本路径与 legacy 路径保持一致。
