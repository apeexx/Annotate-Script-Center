(function () {
  if (globalThis.__ASREdgeAishellTechCantoneseContentInstalled === true) {
    return;
  }
  globalThis.__ASREdgeAishellTechCantoneseContentInstalled = true;

  const CONSTANTS = globalThis.ASREdgeConstants || {};
  const STORAGE = globalThis.ASREdgeStorage || null;
  const DEFAULT_TIMEOUT_MS = Number(CONSTANTS.DEFAULT_AI_REQUEST_TIMEOUT_MS || 60000) || 60000;
  const SCRIPT_ID =
    CONSTANTS.AISHELL_TECH_CANTONESE_SCRIPT_ID || "aishellTechCantoneseAssistant";
  const RECOMMEND_PATH =
    CONSTANTS.AISHELL_TECH_CANTONESE_AI_RECOMMEND_PATH ||
    "/api/aishell-tech/cantonese-helper/ai/recommend";
  const concurrentRequestStreamFactory = globalThis.ASREdgeConcurrentAiRequestStream || null;
  const aiBatchSummary =
    globalThis.ASREdgeAiBatchSummary ||
    (typeof module !== "undefined" && module.exports
      ? require("../../../shared/ai-batch-summary.js")
      : {});
  const createBatchSummaryAccumulator =
    typeof aiBatchSummary.createBatchSummaryAccumulator === "function"
      ? aiBatchSummary.createBatchSummaryAccumulator
      : function () {
          return {
            addResult: function () {},
            getSnapshot: function () {
              return {
                batchResultCount: 0,
                batchPromptTokens: null,
                batchCompletionTokens: null,
                batchTotalTokens: null,
                batchEstimatedCostCny: null,
                batchHasUsageData: false,
                batchHasPriceData: false,
              };
            },
          };
        };

  let activeRuntime = null;
  let currentUrl = location.href;
  let routeTimer = null;

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function createBatchRunId() {
    return [
      "aishell",
      Date.now().toString(36),
      Math.random().toString(36).slice(2, 8),
    ].join("-");
  }

  function normalizeBatchMode(value) {
    return String(value || "").trim().toLowerCase() === "all" ? "all" : "pending";
  }

  function normalizePromptText(value) {
    return String(value || "").replace(/\r\n/g, "\n").trim();
  }

  function getBatchModeMeta(value) {
    const mode = normalizeBatchMode(value);
    if (mode === "all") {
      return {
        mode: "all",
        label: "全部AI批量识别",
        emptyMessage: "当前分包没有可识别条目。",
      };
    }
    return {
      mode: "pending",
      label: "未完成的AI批量识别",
      emptyMessage: "当前分包没有可识别的未完成条目。",
    };
  }

  function normalizeOptionalNumber(value, min, max) {
    if (value === undefined || value === null || value === "") {
      return "";
    }
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < min || numeric > max) {
      return "";
    }
    return numeric;
  }

  function normalizeOptionalInteger(value, min, max) {
    if (value === undefined || value === null || value === "") {
      return "";
    }
    const numeric = Math.floor(Number(value));
    if (!Number.isFinite(numeric) || numeric < min || numeric > max) {
      return "";
    }
    return numeric;
  }

  function normalizeStopSequences(value) {
    const source = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/\r?\n/)
        : [];
    const result = [];
    source.forEach(function (item) {
      const text = String(item || "").trim().slice(0, 80);
      if (!text || result.indexOf(text) >= 0 || result.length >= 8) {
        return;
      }
      result.push(text);
    });
    return result;
  }

  function buildStageParams(config, prefix) {
    const params = {};
    const temperature = normalizeOptionalNumber(config[prefix + "Temperature"], 0, 2);
    if (temperature !== "") {
      params.temperature = temperature;
    }
    const topP = normalizeOptionalNumber(config[prefix + "TopP"], 0, 1);
    if (topP !== "") {
      params.top_p = topP;
    }
    const maxTokens = normalizeOptionalInteger(config[prefix + "MaxTokens"], 1, 8192);
    if (maxTokens !== "") {
      params.max_tokens = maxTokens;
    }
    const maxCompletionTokens = normalizeOptionalInteger(
      config[prefix + "MaxCompletionTokens"],
      1,
      8192
    );
    if (maxCompletionTokens !== "") {
      params.max_completion_tokens = maxCompletionTokens;
    }
    const presencePenalty = normalizeOptionalNumber(
      config[prefix + "PresencePenalty"],
      -2,
      2
    );
    if (presencePenalty !== "") {
      params.presence_penalty = presencePenalty;
    }
    const frequencyPenalty = normalizeOptionalNumber(
      config[prefix + "FrequencyPenalty"],
      -2,
      2
    );
    if (frequencyPenalty !== "") {
      params.frequency_penalty = frequencyPenalty;
    }
    const seed = normalizeOptionalInteger(config[prefix + "Seed"], 0, 2147483647);
    if (seed !== "") {
      params.seed = seed;
    }
    const stop = normalizeStopSequences(config[prefix + "StopSequences"]);
    if (stop.length > 0) {
      params.stop = stop;
    }
    return params;
  }

  function buildAiOmni(config) {
    return {
      model: normalizeText(config.aiRecommendSingleModel),
      prompt: normalizePromptText(config.aiRecommendSinglePrompt),
      params: buildStageParams(config, "aiRecommend"),
    };
  }

  function isMarkPage() {
    return (
      location.hostname === "mark.aishelltech.com" &&
      String(location.pathname || "").toLowerCase() === "/mytask/mark"
    );
  }

  function getDefaultConfig() {
    const defaults =
      CONSTANTS.DEFAULT_SETTINGS?.platforms?.aishellTech?.scripts?.cantoneseHelper || {};
    return Object.assign(
      {
        id: SCRIPT_ID,
        enabled: false,
        aiRecommendEnabled: false,
        aiRecommendRequestTimeoutMs: DEFAULT_TIMEOUT_MS,
        aiQualifiedAutofillConcurrency: 5,
        aiRecommendSingleModel: "qwen3.5-omni-plus",
        aiRecommendSinglePrompt: "",
        aiRecommendEnableThinking: false,
        aiRecommendTemperature: "",
        aiRecommendTopP: "",
        aiRecommendMaxTokens: "",
        aiRecommendMaxCompletionTokens: "",
        aiRecommendPresencePenalty: "",
        aiRecommendFrequencyPenalty: "",
        aiRecommendSeed: "",
        aiRecommendStopSequences: "",
        shortcuts: {},
      },
      defaults || {}
    );
  }

  async function loadRuntimeConfig() {
    const defaults = getDefaultConfig();
    const settings = STORAGE && typeof STORAGE.getSettings === "function"
      ? await STORAGE.getSettings()
      : { platforms: {}, meta: {} };
    const scriptConfig = settings?.platforms?.aishellTech?.scripts?.cantoneseHelper || {};
    const endpoint =
      typeof CONSTANTS.buildBackendUrl === "function"
        ? CONSTANTS.buildBackendUrl(RECOMMEND_PATH, settings)
        : String(CONSTANTS.DEFAULT_BACKEND_BASE_URLS?.server || "").replace(/\/+$/, "") +
          RECOMMEND_PATH;
    const merged = Object.assign({}, defaults, scriptConfig, {
      id: SCRIPT_ID,
      aiRecommendEndpoint: endpoint,
    });
    merged.aiQualifiedAutofillConcurrency = Math.max(
      1,
      Math.floor(Number(merged.aiQualifiedAutofillConcurrency || 5) || 5)
    );
    merged.aiRecommendRequestTimeoutMs = Math.min(
      DEFAULT_TIMEOUT_MS,
      Math.max(1000, Number(merged.aiRecommendRequestTimeoutMs || DEFAULT_TIMEOUT_MS) || DEFAULT_TIMEOUT_MS)
    );
    return {
      config: merged,
      settings: settings || {},
      enabled:
        settings?.platforms?.aishellTech?.enabled !== false &&
        merged.enabled !== false &&
        merged.aiRecommendEnabled !== false,
    };
  }

  function createRuntime(config) {
    const dataApiFactory = globalThis.__ASREdgeAishellTechCantoneseDataApi;
    const segmentClipper = globalThis.__ASREdgeAishellTechCantoneseSegmentAudioClipper;
    const aiFactory = globalThis.__ASREdgeAishellTechCantoneseAiRecommendation;
    const diagnosticsFactory = globalThis.__ASREdgeAishellTechCantoneseDiagnostics || {};
    const uiFactory = globalThis.__ASREdgeAishellTechCantoneseUiPanel;
    const shortcutsFactory = globalThis.__ASREdgeAishellTechCantoneseShortcuts;
    const buildBatchFailureEntry =
      typeof diagnosticsFactory.buildBatchFailureEntry === "function"
        ? diagnosticsFactory.buildBatchFailureEntry
        : function (input) {
            const source = input && typeof input === "object" ? input : {};
            return {
              displayName: source.task?.displayName || "未知条目",
              message: source.message || "失败",
              stage: source.stage || "unknown",
              stageLabel: source.stage || "unknown",
              detailRows: [],
              rawJson:
                source.error?.rawResponse && typeof source.error.rawResponse === "object"
                  ? source.error.rawResponse
                  : {},
            };
          };

    if (
      !dataApiFactory?.createRuntime ||
      !segmentClipper?.createAudioClipSession ||
      !aiFactory?.createRuntime ||
      !concurrentRequestStreamFactory?.createConcurrentAiRequestStream ||
      !uiFactory?.createRuntime
    ) {
      return null;
    }

    const dataApi = dataApiFactory.createRuntime();
    const aiClient = aiFactory.createRuntime({
      endpoint: config.aiRecommendEndpoint,
      timeoutMs: config.aiRecommendRequestTimeoutMs,
      settings: config.settings || {},
      aiOmni: buildAiOmni(config),
    });

    const panel = uiFactory.createRuntime({
      onRecommend: handleRecommend,
      onBatchRecommendAll: handleBatchRecommendAll,
      onBatchRecommendPending: handleBatchRecommendPending,
      onBatchStop: handleBatchStop,
      canFillPageText: dataApi.canFillPageText,
      fillPageText: dataApi.fillPageText,
      getCurrentItem: dataApi.getCurrentItem,
    });
    const shortcuts = shortcutsFactory?.createRuntime
      ? shortcutsFactory.createRuntime({
          shortcuts: config.shortcuts || {},
          actions: {
            requestAiRecommend: handleRecommend,
            autoFillQualifiedItem: handleBatchRecommendPending,
            copyRecommendedText: panel.copyRecommendedText,
            fillRecommendedText: panel.fillRecommendedText,
            ignoreAiResult: panel.ignoreAiResult,
            showStatus: panel.setStatus,
          },
        })
      : null;

    let mountTimer = null;
    let currentBusyState = {
      single: false,
      batch: false,
    };
    let batchStopRequested = false;
    let activeBatchContext = null;
    const activeRequestControllers = new Set();
    let activeSaveController = null;

    function syncBusyState(nextState) {
      currentBusyState = Object.assign({}, currentBusyState, nextState || {});
      panel.setBusy(currentBusyState);
    }

    function abortActiveRequests() {
      activeRequestControllers.forEach(function (controller) {
        try {
          controller.abort();
        } catch (_error) {
          // A best-effort stop must not prevent the rest of the batch from closing.
        }
      });
    }

    function abortActiveSave() {
      if (!activeSaveController) {
        return;
      }
      try {
        activeSaveController.abort();
      } catch (_error) {
        // A best-effort stop must not prevent the rest of the batch from closing.
      }
    }

    function releaseClipSession(session) {
      try {
        session?.release?.();
      } catch (_error) {
        // Releasing a local decoded buffer is best-effort cleanup only.
      }
    }

    async function buildCroppedSegmentItem(item, clipSession, signal) {
      if (!item?.audioUrl || !item?.selectionKey) {
        throw new Error("当前条目或蓝色区段信息不完整，不能裁剪音频。");
      }
      const audioDataUrl = await clipSession.createAudioDataUrl(item, signal);
      if (!audioDataUrl) {
        throw new Error("当前蓝色区段裁剪失败，未发送整条音频。");
      }
      return Object.assign({}, item, { audioDataUrl: audioDataUrl });
    }

    async function handleRecommend() {
      syncBusyState({ single: true });
      panel.setStatus("正在识别当前条...", "info");
      try {
        const item = await dataApi.getCurrentItem();
        if (!item) {
          throw new Error("当前页面还没有定位到选中条目。");
        }
        panel.updateCurrentItemKey(item.key);
        const clipSession = segmentClipper.createAudioClipSession(item.audioUrl);
        let result;
        try {
          const croppedItem = await buildCroppedSegmentItem(item, clipSession);
          result = await aiClient.recommend(croppedItem);
        } finally {
          releaseClipSession(clipSession);
        }
        const selectedItem = await dataApi.getCurrentItem();
        panel.updateCurrentItemKey(selectedItem?.key || "");
        const renderMeta = panel.renderResult(
          Object.assign({}, result, {
            currentText: item.existingDisplayText || item.existingMarkText,
            listenText: result.listenText,
            taskItemId: item.taskItemId,
            itemKey: item.key,
          })
        ) || {};
        panel.setStatus(
          renderMeta.canApply
            ? "当前条识别完成。"
            : "当前已切换到其他条目，上一条识别结果不能填入，请重新识别。",
          renderMeta.canApply ? "success" : "warning"
        );
      } catch (error) {
        panel.setStatus(error?.message || String(error), "error", error?.rawResponse || null);
      } finally {
        syncBusyState({ single: false });
      }
    }

    async function handleBatchStop() {
      if (currentBusyState.batch !== true) {
        panel.setStatus("当前没有正在运行的批量识别。", "warning");
        return;
      }
      batchStopRequested = true;
      if (activeBatchContext?.requestStream?.cancelPending) {
        activeBatchContext.requestStream.cancelPending("批量识别已手动停止。");
      }
      if (typeof activeBatchContext?.abortActiveRequests === "function") {
        activeBatchContext.abortActiveRequests();
      }
      if (typeof activeBatchContext?.releaseClipSession === "function") {
        activeBatchContext.releaseClipSession();
      }
      if (typeof activeBatchContext?.notifyStopSignal === "function") {
        activeBatchContext.notifyStopSignal();
      }
      const batchMeta = getBatchModeMeta(activeBatchContext?.mode);
      panel.setStatus(
        "已请求停止，正在取消已发起的 AI 任务并结束本轮" + batchMeta.label + "。",
        "warning"
      );
      panel.updateBatch({
        phaseText: batchMeta.label + "停止中",
        running: true,
      });
    }

    async function runBatchRecommend(mode) {
      const batchMeta = getBatchModeMeta(mode);
      let batchClosed = false;
      let clipSession = null;
      syncBusyState({ batch: true });
      batchStopRequested = false;
      panel.setStatus("正在准备" + batchMeta.label + "...", "info");
      try {
        const batchPlan = await dataApi.getBatchSegmentPlanForCurrentAudio({
          mode: batchMeta.mode,
          timeoutMs: 12000,
        });
        const tasks = Array.isArray(batchPlan?.tasks) ? batchPlan.tasks : [];
        const preflightFailures = Array.isArray(batchPlan?.preflightFailures)
          ? batchPlan.preflightFailures
          : [];
        const failures = preflightFailures.map(function (failure) {
          return buildBatchFailureEntry({
            task: failure,
            stage: failure.stage || "segment_preflight",
            message: failure.message || "蓝色区段预检失败。",
            error: failure.error,
          });
        });
        const totalSegmentCount = tasks.length + failures.length;
        if (!tasks.length) {
          panel.updateBatch({
            phaseText: batchMeta.label + "无可安全处理区段",
            total: totalSegmentCount,
            completed: failures.length,
            failed: failures.length,
            currentText: "",
            failures: failures,
            running: false,
          });
          panel.setStatus(
            failures.length > 0
              ? "当前分包没有可安全裁剪的区段，已跳过预检失败段且未发起 AI 请求。"
              : batchMeta.emptyMessage,
            "warning"
          );
          return;
        }
        const batchRunId = createBatchRunId();
        const batchConcurrency = Math.max(
          1,
          Number(config.aiQualifiedAutofillConcurrency || 5) || 5
        );
        const batchSummaryAccumulator = createBatchSummaryAccumulator();
        let completedCount = failures.length;
        let processedTaskCount = 0;
        let currentPhaseText = batchMeta.label + "开始";
        let currentDisplayText = tasks[0].displayName || "";
        let requestStream = null;
        clipSession = segmentClipper.createAudioClipSession(tasks[0].audioUrl);
        let resolveStopSignal = null;
        const stopSignalPromise = new Promise(function (resolve) {
          resolveStopSignal = resolve;
        });

        function notifyStopSignal() {
          if (typeof resolveStopSignal === "function") {
            resolveStopSignal({ type: "stop" });
            resolveStopSignal = null;
          }
        }

        function updateBatchSnapshot(phaseText, currentText, running) {
          if (!requestStream) {
            return;
          }
          if (typeof phaseText === "string" && phaseText) {
            currentPhaseText = phaseText;
          }
          if (currentText !== undefined) {
            currentDisplayText = String(currentText || "");
          }
          const snapshot = requestStream.getSnapshot();
          panel.updateBatch({
            phaseText: currentPhaseText,
            total: totalSegmentCount,
            completed: completedCount,
            failed: failures.length,
            currentText: currentDisplayText,
            failures: failures,
            running: running !== false,
            frontConcurrency: snapshot.frontConcurrency,
            requestStaggerMs: snapshot.requestStaggerMs,
            launchedCount: snapshot.launchedCount,
            activeAiCount: snapshot.activeAiCount,
            completedAiCount: snapshot.completedAiCount,
            bufferedCount: snapshot.bufferedCount,
            ...batchSummaryAccumulator.getSnapshot(),
          });
        }

        requestStream = concurrentRequestStreamFactory.createConcurrentAiRequestStream({
          tasks: tasks,
          concurrency: batchConcurrency,
          staggerMs: 50,
          onStateChange: function () {
            if (batchClosed === true) {
              return;
            }
            updateBatchSnapshot(currentPhaseText, currentDisplayText, true);
          },
          runTask: async function (task, index) {
            const item = Object.assign({}, task);
            item.batchRunId = batchRunId;
            item.batchItemIndex = Number(task.segmentNumber || task.index || 0) || index + 1;
            item.batchProcessKey =
              "task-segment:" + String(item.taskItemId || "unknown") + ":" + String(item.selectionKey || "unknown");
            item.clientRequestId = [
              batchRunId,
              String(item.batchItemIndex),
              String(item.taskItemId || "unknown"),
              String(item.selectionKey || "unknown"),
            ].join(":");
            item.frontConcurrency = batchConcurrency;
            const controller =
              typeof AbortController === "function" ? new AbortController() : null;
            if (controller) {
              activeRequestControllers.add(controller);
            }
            try {
              const croppedItem = await buildCroppedSegmentItem(
                item,
                clipSession,
                controller ? controller.signal : undefined
              );
              return await aiClient.recommend(croppedItem, {
                signal: controller ? controller.signal : undefined,
              });
            } finally {
              if (controller) {
                activeRequestControllers.delete(controller);
              }
            }
          },
        });

        activeBatchContext = {
          mode: batchMeta.mode,
          requestStream: requestStream,
          batchRunId: batchRunId,
          notifyStopSignal: notifyStopSignal,
          abortActiveRequests: abortActiveRequests,
          releaseClipSession: function () {
            releaseClipSession(clipSession);
          },
        };

        updateBatchSnapshot(batchMeta.label + "开始", tasks[0].displayName, true);

        const pendingEntriesByIndex = new Map();
        let nextSaveIndex = 0;
        while (processedTaskCount < tasks.length) {
          if (batchStopRequested === true) {
            break;
          }
          let entry = pendingEntriesByIndex.get(nextSaveIndex) || null;
          if (!entry) {
            const outcome = await Promise.race([
              requestStream.nextResult().then(function (nextEntry) {
                return {
                  type: "result",
                  entry: nextEntry,
                };
              }),
              stopSignalPromise,
            ]);
            if (outcome?.type === "stop") {
              break;
            }
            const arrivedEntry = outcome?.entry || null;
            if (!arrivedEntry) {
              break;
            }
            pendingEntriesByIndex.set(arrivedEntry.index, arrivedEntry);
            continue;
          }
          pendingEntriesByIndex.delete(nextSaveIndex);
          if (batchStopRequested === true) {
            break;
          }
          const task = entry.task;
          updateBatchSnapshot(
            entry.ok === true ? batchMeta.label + "回填保存中" : batchMeta.label + "当前条失败",
            task.displayName,
            true
          );
          if (entry.ok !== true) {
            processedTaskCount += 1;
            completedCount += 1;
            failures.push(
              buildBatchFailureEntry({
                task: task,
                stage: "ai_request",
                message: entry.error?.message || String(entry.error),
                error: entry.error,
                batchConcurrency: batchConcurrency,
              })
            );
            updateBatchSnapshot(batchMeta.label + "当前条失败", task.displayName, true);
          } else {
            batchSummaryAccumulator.addResult(entry.value);
            if (!String(entry.value?.listenText || "")) {
              processedTaskCount += 1;
              completedCount += 1;
              failures.push(
                buildBatchFailureEntry({
                  task: task,
                  stage: "empty_result",
                  message: "该蓝色区段未识别到文本，已标记为需人工复核且未填入、未保存。",
                  result: entry.value,
                  batchConcurrency: batchConcurrency,
                })
              );
              updateBatchSnapshot(batchMeta.label + "需人工复核", task.displayName, true);
              nextSaveIndex += 1;
              continue;
            }
            let switchResult = null;
            let saveResult = null;
            let failureStage = "select_segment";
            try {
              switchResult = await dataApi.selectSegmentByNumber(task.segmentNumber, {
                timeoutMs: 12000,
              });
              if (switchResult?.ok === false) {
                throw new Error(switchResult.message || "切换蓝色区段失败。");
              }
              if (batchStopRequested === true) {
                break;
              }
              panel.renderResult(
                Object.assign({}, entry.value, {
                  currentText:
                    dataApi.getCurrentInputDisplayValue?.() || dataApi.getCurrentInputValue?.() || "",
                  listenText: entry.value.listenText,
                  taskItemId: task.taskItemId,
                  itemKey: task.key,
                })
              );
              failureStage = "save_current";
              const saveController = new AbortController();
              activeSaveController = saveController;
              try {
                saveResult = await dataApi.fillAndSaveCurrent(
                  entry.value.listenText || "",
                  {
                    timeoutMs: 15000,
                    signal: saveController.signal,
                    expectedTaskItemId: task.taskItemId,
                    expectedSelectionKey: task.selectionKey,
                  }
                );
              } finally {
                if (activeSaveController === saveController) {
                  activeSaveController = null;
                }
              }
              if (saveResult?.ok === false) {
                throw new Error(saveResult.message || "填入并保存失败。");
              }
              processedTaskCount += 1;
              completedCount += 1;
              updateBatchSnapshot(batchMeta.label + "已识别并保存", task.displayName, true);
            } catch (error) {
              processedTaskCount += 1;
              completedCount += 1;
              failures.push(
                buildBatchFailureEntry({
                  task: task,
                  stage: failureStage,
                  message: error?.message || String(error),
                  error: error,
                  result: entry.value,
                  switchResult: switchResult,
                  saveResult: saveResult,
                  batchConcurrency: batchConcurrency,
                })
              );
              updateBatchSnapshot(batchMeta.label + "当前条失败", task.displayName, true);
            }
          }
          nextSaveIndex += 1;
        }

        if (batchStopRequested === true) {
          updateBatchSnapshot(batchMeta.label + "已停止", "", false);
          panel.setStatus("本轮" + batchMeta.label + "已按请求停止。", "warning");
          return;
        }

        await requestStream.whenProducersDone;
        updateBatchSnapshot(batchMeta.label + "已完成", "", false);
        panel.setStatus(
          failures.length > 0
            ? "当前分包" + batchMeta.label + "完成，存在失败条目。"
            : "当前分包" + batchMeta.label + "完成。",
          failures.length > 0 ? "warning" : "success"
        );
      } catch (error) {
        panel.setStatus(error?.message || String(error), "error");
      } finally {
        batchClosed = true;
        releaseClipSession(clipSession);
        activeBatchContext = null;
        batchStopRequested = false;
        syncBusyState({ batch: false });
      }
    }

    async function handleBatchRecommendAll() {
      return runBatchRecommend("all");
    }

    async function handleBatchRecommendPending() {
      return runBatchRecommend("pending");
    }

    function ensureMounted() {
      panel.ensureMounted();
      void dataApi
        .getCurrentItem()
        .then(function (item) {
          panel.updateCurrentItemKey(item?.key || "");
        })
        .catch(function () {});
    }

    function start() {
      dataApi.start();
      shortcuts?.start?.();
      ensureMounted();
      mountTimer = window.setInterval(ensureMounted, 1200);
      panel.setStatus("粤语助手已就绪。", "success");
    }

    function stop() {
      if (mountTimer) {
        window.clearInterval(mountTimer);
        mountTimer = null;
      }
      shortcuts?.stop?.();
      dataApi.stop();
      panel.remove();
    }

    return {
      start,
      stop,
    };
  }

  function stopRuntime() {
    if (activeRuntime) {
      activeRuntime.stop();
      activeRuntime = null;
    }
  }

  async function evaluatePage() {
    if (!isMarkPage()) {
      stopRuntime();
      return;
    }
    const runtimeConfig = await loadRuntimeConfig();
    if (!runtimeConfig.enabled) {
      stopRuntime();
      return;
    }
    if (!activeRuntime) {
      const runtime = createRuntime(
        Object.assign({}, runtimeConfig.config || {}, {
          settings: runtimeConfig.settings || {},
        })
      );
      if (!runtime) {
        return;
      }
      activeRuntime = runtime;
      activeRuntime.start();
    }
  }

  function startRouteWatch() {
    if (routeTimer) {
      return;
    }
    routeTimer = window.setInterval(function () {
      if (location.href !== currentUrl) {
        currentUrl = location.href;
        void evaluatePage().catch(function (error) {
          console.warn("[Aishell][cantonese-helper] route evaluate failed", error?.message || error);
        });
      }
    }, 300);
  }

  function bootstrap() {
    startRouteWatch();
    void evaluatePage().catch(function (error) {
      console.warn("[Aishell][cantonese-helper] bootstrap failed", error?.message || error);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
  } else {
    bootstrap();
  }
})();
